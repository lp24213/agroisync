# 🚀 AGROTM - INSTRUÇÕES DE DEPLOY NA AWS

## 📋 **VISÃO GERAL**

**AGROTM** está completamente preparado para deploy na AWS com:
- ✅ **Frontend Next.js** otimizado para Amplify
- ✅ **Backend Express.js** pronto para EC2/ECS
- ✅ **Todas as funcionalidades** preservadas
- ✅ **Configurações de segurança** implementadas
- ✅ **Docker** configurado
- ✅ **Monitoramento** configurado

---

## ⚡ **DEPLOY RÁPIDO - AWS AMPLIFY**

### **Passo 1: Frontend no Amplify**

1. **Acesse AWS Amplify Console**
2. **Conecte repositório GitHub**
3. **Configure build settings:**

```yaml
Build command: cd frontend && npm ci && npm run build
Output directory: frontend/.next/standalone
Node version: 20.x
```

4. **Configure variáveis de ambiente:**

```bash
NODE_ENV=production
NEXT_PUBLIC_API_URL=https://seu-backend.aws.com
NEXT_PUBLIC_FIREBASE_API_KEY=sua_chave
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=seu_dominio
NEXT_PUBLIC_FIREBASE_PROJECT_ID=seu_projeto
```

### **Passo 2: Backend no EC2**

1. **Criar instância EC2 (t3.medium)**
2. **Configurar security group (porta 3001)**
3. **Deploy via Docker:**

```bash
cd backend
docker build -t agrotm-backend .
docker run -d -p 3001:3001 --name agrotm-backend agrotm-backend
```

---

## 🐳 **DEPLOY COMPLETO VIA DOCKER**

### **Preparar ambiente:**

```bash
# Instalar Docker
sudo yum update -y
sudo yum install -y docker
sudo service docker start
sudo usermod -a -G docker ec2-user

# Instalar Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
```

### **Configurar variáveis:**

```bash
# Copiar arquivos de exemplo
cp frontend/env.example frontend/.env.local
cp backend/env.example backend/.env

# Editar com suas credenciais
nano frontend/.env.local
nano backend/.env
```

### **Executar deploy:**

```bash
# Deploy completo
docker-compose up -d

# Verificar status
docker-compose ps
docker-compose logs -f
```

---

## 🔧 **CONFIGURAÇÕES ESPECÍFICAS**

### **Frontend (Porta 3000):**
- ✅ `next.config.js` otimizado para AWS
- ✅ `output: 'standalone'` configurado
- ✅ Headers de segurança implementados
- ✅ CORS configurado para AWS

### **Backend (Porta 3001):**
- ✅ `server.js` configurado para produção
- ✅ CORS configurado para frontend
- ✅ Helmet para segurança
- ✅ Rate limiting configurado

---

## 🌐 **DOMÍNIOS E SSL**

### **Configurar domínio:**

1. **AWS Route 53:**
   - Criar hosted zone para `agrotmsol.com.br`
   - Configurar registros A para frontend
   - Configurar registros A para backend

2. **SSL automático:**
   - AWS Certificate Manager
   - Solicitar certificado para `*.agrotmsol.com.br`
   - Aplicar no Amplify e Load Balancer

---

## 📊 **MONITORAMENTO**

### **CloudWatch:**
- ✅ Logs para EC2 configurados
- ✅ Métricas de performance
- ✅ Alertas automáticos

### **Health Checks:**
- ✅ Frontend: `/api/health`
- ✅ Backend: `/health`
- ✅ Configurar no Load Balancer

---

## 🔒 **SEGURANÇA**

### **Security Groups:**
- ✅ Frontend: Porta 443 (HTTPS)
- ✅ Backend: Porta 3001 (HTTP/HTTPS)
- ✅ SSH: Porta 22 (IPs autorizados)

### **IAM Roles:**
- ✅ Roles específicos para EC2
- ✅ Permissões mínimas necessárias
- ✅ Rotação de chaves automática

---

## 🚨 **RESOLUÇÃO DE PROBLEMAS**

### **Build falhando:**
```bash
# Verificar Node.js 20.x
node --version

# Limpar cache
npm run clean

# Verificar dependências
npm audit fix
```

### **CORS errors:**
```bash
# Verificar ALLOWED_ORIGINS no backend
# Configurar corretamente no frontend
# Testar conectividade entre serviços
```

### **Banco não conecta:**
```bash
# Verificar MongoDB connection string
# Verificar security groups
# Testar conectividade
```

---

## 📞 **SUPORTE**

### **Logs importantes:**
- ✅ **Frontend**: Amplify Console
- ✅ **Backend**: CloudWatch
- ✅ **Docker**: `docker-compose logs`

### **Comandos úteis:**
```bash
# Reiniciar serviços
docker-compose restart

# Ver logs em tempo real
docker-compose logs -f

# Acessar container
docker exec -it agrotm-backend bash

# Backup banco
docker exec agrotm-backend npm run backup
```

---

## ✅ **CHECKLIST FINAL**

- [ ] **Frontend configurado** no AWS Amplify
- [ ] **Backend rodando** na porta 3001
- [ ] **Variáveis de ambiente** configuradas
- [ ] **CORS configurado** corretamente
- [ ] **SSL configurado** para domínio
- [ ] **Health checks** funcionando
- [ ] **Monitoramento** ativo
- [ ] **Backup** configurado
- [ ] **Testes** executados
- [ ] **Documentação** atualizada

---

## 🎯 **RESULTADO FINAL**

Após o deploy, você terá:

- 🌐 **Frontend**: https://agrotmsol.com.br (porta 3000)
- 🔌 **Backend**: https://api.agrotmsol.com.br (porta 3001)
- 📱 **Aplicação completa** funcionando
- 🔒 **Segurança** configurada
- 📊 **Monitoramento** ativo
- 🚀 **Performance** otimizada

---

**🎉 AGROTM TOTALMENTE FUNCIONAL NA AWS! 🎉**

*Projeto preparado para produção com todas as funcionalidades preservadas.*

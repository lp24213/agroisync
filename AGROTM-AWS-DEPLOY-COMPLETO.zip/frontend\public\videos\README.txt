Este diretório armazena o vídeo institucional do projeto AGROTM.
O vídeo real pode ser substituído por um arquivo .mp4 em produção (ex: public/videos/agrotm-pitch.mp4).
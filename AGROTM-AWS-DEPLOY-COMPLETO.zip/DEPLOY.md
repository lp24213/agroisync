# 🚀 AGROTM - DEPLOY COMPLETO NA AWS

## 📋 **VISÃO GERAL DO PROJETO**

**AGROTM** é uma plataforma completa de tokenização agrícola com:
- ✅ **Frontend Next.js** com interface premium
- ✅ **Backend Express.js** com APIs robustas
- ✅ **Integração MongoDB** para dados
- ✅ **Firebase Functions** para autenticação
- ✅ **Blockchain Solana** para NFTs e staking
- ✅ **Chatbot AI** integrado
- ✅ **Sistema multilíngue** (PT, EN, ES, ZH)
- ✅ **Dashboard analítico** completo
- ✅ **Marketplace NFT** funcional

---

## 🏗️ **ESTRUTURA DO PROJETO**

```
agrotm-aws-deploy/
├── frontend/          # Aplicação Next.js
├── backend/           # APIs Express.js
├── amplify.yml        # Configuração AWS Amplify
├── docker-compose.yml # Orquestração Docker
├── Dockerfile         # Container principal
└── DEPLOY.md          # Este arquivo
```

---

## ⚡ **DEPLOY RÁPIDO - AWS AMPLIFY (RECOMENDADO)**

### **1. Frontend no AWS Amplify:**

```bash
# 1. Conectar repositório GitHub
# 2. Configurar build settings:
Build command: cd frontend && npm ci && npm run build
Output directory: frontend/.next/standalone
Node version: 20.x

# 3. Variáveis de ambiente (Amplify Console):
NODE_ENV=production
NEXT_PUBLIC_API_URL=https://seu-backend.aws.com
NEXT_PUBLIC_FIREBASE_API_KEY=sua_chave
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=seu_dominio
NEXT_PUBLIC_FIREBASE_PROJECT_ID=seu_projeto
```

### **2. Backend no AWS EC2/ECS:**

```bash
# 1. Criar instância EC2 (t3.medium ou superior)
# 2. Configurar security groups (porta 3001)
# 3. Deploy via Docker:

cd backend
docker build -t agrotm-backend .
docker run -d -p 3001:3001 --name agrotm-backend agrotm-backend
```

---

## 🐳 **DEPLOY COMPLETO VIA DOCKER**

### **1. Preparar ambiente:**

```bash
# Instalar Docker e Docker Compose
# Clonar projeto
git clone <seu-repositorio>
cd agrotm-aws-deploy
```

### **2. Configurar variáveis de ambiente:**

```bash
# Frontend (.env.local)
cp frontend/env.example frontend/.env.local
# Editar com suas credenciais

# Backend (.env)
cp backend/env.example backend/.env
# Editar com suas credenciais
```

### **3. Executar deploy:**

```bash
# Deploy completo
docker-compose up -d

# Verificar status
docker-compose ps
docker-compose logs -f
```

---

## 🔧 **CONFIGURAÇÕES ESPECÍFICAS**

### **Frontend (Porta 3000):**

```javascript
// next.config.js já configurado para AWS Amplify
// output: 'standalone' para melhor performance
// Headers de segurança configurados
// CORS configurado para AWS
```

### **Backend (Porta 3001):**

```javascript
// server.js configurado para produção
// CORS configurado para frontend
// Helmet para segurança
// Rate limiting configurado
```

---

## 🌐 **DOMÍNIOS E SSL**

### **1. Configurar domínio personalizado:**

```bash
# AWS Route 53
# Criar hosted zone para agrotmsol.com.br
# Configurar registros A para frontend
# Configurar registros A para backend
```

### **2. SSL automático:**

```bash
# AWS Certificate Manager
# Solicitar certificado para *.agrotmsol.com.br
# Aplicar no Amplify e Load Balancer
```

---

## 📊 **MONITORAMENTO E LOGS**

### **1. CloudWatch:**

```bash
# Configurar logs para EC2
# Métricas de performance
# Alertas automáticos
```

### **2. Health Checks:**

```bash
# Frontend: /api/health
# Backend: /health
# Configurar no Load Balancer
```

---

## 🔒 **SEGURANÇA**

### **1. Security Groups:**

```bash
# Frontend: Porta 443 (HTTPS)
# Backend: Porta 3001 (HTTP/HTTPS)
# SSH: Porta 22 (apenas IPs autorizados)
```

### **2. IAM Roles:**

```bash
# Criar roles específicos para EC2
# Permissões mínimas necessárias
# Rotação de chaves automática
```

---

## 🚨 **TROUBLESHOOTING**

### **Problemas comuns:**

```bash
# 1. Build falhando:
- Verificar Node.js 20.x
- Limpar cache: npm run clean
- Verificar dependências

# 2. CORS errors:
- Verificar ALLOWED_ORIGINS no backend
- Configurar corretamente no frontend

# 3. Banco não conecta:
- Verificar MongoDB connection string
- Verificar security groups
- Testar conectividade
```

---

## 📞 **SUPORTE**

### **Logs importantes:**

```bash
# Frontend logs: Amplify Console
# Backend logs: CloudWatch
# Docker logs: docker-compose logs
```

### **Comandos úteis:**

```bash
# Reiniciar serviços
docker-compose restart

# Ver logs em tempo real
docker-compose logs -f

# Acessar container
docker exec -it agrotm-backend bash

# Backup banco
docker exec agrotm-backend npm run backup
```

---

## ✅ **CHECKLIST DE DEPLOY**

- [ ] **Frontend configurado** no AWS Amplify
- [ ] **Backend rodando** na porta 3001
- [ ] **Variáveis de ambiente** configuradas
- [ ] **CORS configurado** corretamente
- [ ] **SSL configurado** para domínio
- [ ] **Health checks** funcionando
- [ ] **Monitoramento** ativo
- [ ] **Backup** configurado
- [ ] **Testes** executados
- [ ] **Documentação** atualizada

---

## 🎯 **RESULTADO FINAL**

Após o deploy, você terá:

- 🌐 **Frontend**: https://agrotmsol.com.br (porta 3000)
- 🔌 **Backend**: https://api.agrotmsol.com.br (porta 3001)
- 📱 **Aplicação completa** funcionando
- 🔒 **Segurança** configurada
- 📊 **Monitoramento** ativo
- 🚀 **Performance** otimizada

---

**🎉 AGROTM TOTALMENTE FUNCIONAL NA AWS! 🎉**

*Projeto preparado para produção com todas as funcionalidades preservadas.*
